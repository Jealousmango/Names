score = input('Enter your score: ')
if 90 <= score <= 100:
    print "Your grade is A"
if 80 <= score <= 89:
    print "Your grade is B"
if 70 <= score <= 79:
    print "Your grade is C"
if 60 <= score <= 69:
    print "Your grade is D"
if 00 <= score <= 59:
    print "You are dumb"
