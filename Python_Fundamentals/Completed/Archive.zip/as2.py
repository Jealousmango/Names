for i in range(5,1000000):
    if i % 5 == 0:
        print i
