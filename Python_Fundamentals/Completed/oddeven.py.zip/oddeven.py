for i in range(1,2001):
    print "Number is %s" % i
    if i % 2 == 0:
        print "%s is an even number" % i
    if i % 2 != 0:
        print "%s is an odd number" % i
