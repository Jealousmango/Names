a = [1, 2, 5, 10, 255, 3]
sum=0
for element in a:
    sum+=element
print sum / len(a)
